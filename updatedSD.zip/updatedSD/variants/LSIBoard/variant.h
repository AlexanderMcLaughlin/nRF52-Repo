/*
  This variant describes the Limbitless Solutions Inc. Board
*/

#ifndef _VARIANT_GENERIC_
#define _VARIANT_GENERIC_

/** Master clock frequency */
#ifdef NRF52
#define VARIANT_MCK       (64000000ul)
#else
#define VARIANT_MCK       (16000000ul)
#endif

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/

#include "WVariant.h"

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

// Number of pins defined in PinDescription array
#define PINS_COUNT           (32u)
#define NUM_DIGITAL_PINS     (32u)
#define NUM_ANALOG_INPUTS    (5u)
#define NUM_ANALOG_OUTPUTS   (0u)

// LEDs
#define BLU_LED              (14) // P0_13 Blue LED
#define GRN_LED				 (26) // P0_26 Green LED
#define RED_LED				 (16) // P0_16 Red LED
#define LED_BUILTIN          RED_LED

// Analog pins
#define PIN_A0               (23) // A0
#define PIN_A1               (9)  // A1
#define PIN_A2               (12) // A2
//#define PIN_A3             (x1) // P0.x1 		//Not Defined
//#define PIN_A4             (x2) // P0.x2		//Not Defined
//#define PIN_A5             (x3) // P0.x3		//Not Defined
#define PIN_A6				 (4)  // A6
#define PIN_A7				 (29) // A7

static const uint8_t A0  = PIN_A0 ;
static const uint8_t A1  = PIN_A1 ;
static const uint8_t A2  = PIN_A2 ;
//static const uint8_t A3  = PIN_A3 ;
//static const uint8_t A4  = PIN_A4 ;
//static const uint8_t A5  = PIN_A5 ;
static const uint8_t A6  = PIN_A6 ;
static const uint8_t A7  = PIN_A7 ;

/*
 * Special Pins
 */
// Finger pins (Motor pins for left hand)
#define PIN_F0				 (13) // D2
#define PIN_F1				 (8)  // D3
#define PIN_F2				 (7)  // D4
#define PIN_F3				 (6)  // D5
#define PIN_F4				 (15) // D6
#define PIN_F5				 (27) // D7

// Finger pins (Motor pins for right hand)
#define PIN_F6				 (2)  // D8
#define PIN_F7				 (25) // D9
#define PIN_F8				 (31) // D10
#define PIN_F9				 (11) // D11
#define PIN_F10				 (30) // D12
#define PIN_F11				 (19) // D13

static const uint8_t FINGER[] = {PIN_F0, PIN_F1, PIN_F2, PIN_F3, PIN_F4,
								PIN_F5, PIN_F6, PIN_F7, PIN_F8, PIN_F9,
								PIN_F10, PIN_F11};

// Switch pins (Used in multiplexor controller)
#define PIN_SWITCH0			 PIN_A0 // A0
#define PIN_SWITCH1			 PIN_A1 // A1
#define PIN_SWITCH2 		 PIN_A2 // A2

static const uint8_t SWITCH[] = {PIN_SWITCH0, PIN_SWITCH1, PIN_SWITCH2};

// Special pins
#define POWER 				 (24) 		// PWR
#define BUTTON 				 (21)  		// BUTTON
#define EMG 				 (PIN_A6) 	// A6
#define SENSOR 				 (PIN_A7)	// A7
#define MEASURE 			 (5)  		// MEASURE
#define CC 					 (8) 		// RESET
#define BAT_STAT 			 (10) 		// STAT

// Analog to digital conversion
#ifdef NRF52
#define ADC_RESOLUTION    14
#else
#define ADC_RESOLUTION    10
#endif

/*
 * Serial interfaces
 */
// Serial
#define PIN_SERIAL_RX       (0)
#define PIN_SERIAL_TX       (3)

/*
 * SPI Interfaces

#define SPI_INTERFACES_COUNT 1

#define PIN_SPI_MISO         (21) // P0.22
#define PIN_SPI_MOSI         (23) // P0.23
#define PIN_SPI_SCK          (24) // P0.24

static const uint8_t SS   = 25 ;  // P0.25
static const uint8_t MOSI = PIN_SPI_MOSI ;
static const uint8_t MISO = PIN_SPI_MISO ;
static const uint8_t SCK  = PIN_SPI_SCK ;
 */

/*
 * Wire Interfaces
 */
#define WIRE_INTERFACES_COUNT 1

#define PIN_WIRE_SDA         (20u) // P0.20
#define PIN_WIRE_SCL         (22u) // P0.22

static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

#ifdef __cplusplus
}
#endif

#endif
